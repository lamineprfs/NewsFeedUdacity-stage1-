package com.dznextgeneration.newsfeedudacity;


import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by Lamine on 1/3/2018.
 */

public class NewsAdapter extends ArrayAdapter<News> {

    /**
     * Construct a new {@link NewsAdapter}.
     *
     * @param context of the app .
     * @param  newsList is the list of earthquakes, which is the data source of the adapter.
     */
    public NewsAdapter(@NonNull Context context, List<News> newsList) {

        super(context,0, newsList);
    }

    /**
     * @return a list view the display the information about the newsList at the given
     * position in the list of newsList .
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // check if there is an existing list item (called convertView) that we can use,
        // otherwise if convertView is null, then inflate a new list item layout .
        View listItemView = convertView ;
        if (listItemView == null){
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false) ;
        }

        // Find the earthquake at the given position of the list of earthquakes .
        News currentNews = getItem(position) ;

        // Find the textView with the title_subject ID .
        TextView title = listItemView.findViewById(R.id.title_subject);

        // Display the title of the current news in that TextView
        title.setText(currentNews.getTitle());

        // Find the textView with the date ID .
        TextView date = listItemView.findViewById(R.id.date);

        // Display the date of the current news in that TextView
        date.setText(formatDate(currentNews.getDate()));

        // Find the textView with the type ID .
        TextView type = listItemView.findViewById(R.id.type);

        // Display the type of the current news in that TextView
        type.setText(currentNews.getType());

        // Find the textView with the category ID .
        TextView category = listItemView.findViewById(R.id.category);

        // Display the category of the current news in that TextView
        category.setText(currentNews.getCategory());

        // Set the proper background color on the magnitude circle.
        // Fetch the background from the TextView, which is a GradientDrawable.
        GradientDrawable categoryRectangle = (GradientDrawable) category.getBackground();
        // Get the appropriate background color based on the current earthquake magnitude
        int categoryColor = getCategoryColor(currentNews.getCategory());
        // Set the color on the magnitude circle
        categoryRectangle.setColor(categoryColor);

        return listItemView;
    }

    /**
     * Return the color for the category rectangle based on the name of the category.
     *
     * @param category of the news
     */
    private int getCategoryColor(String category) {
        int categoryColorId;
        switch (category) {
            case "Sport":
                categoryColorId = R.color.sport;
                break;
            case "World news":
                categoryColorId = R.color.worldNews;
                break;
            case "US news":
                categoryColorId = R.color.usNews;
                break;
            case "Football":
                categoryColorId = R.color.football;
                break;
            case "Environment":
                categoryColorId = R.color.environment;
                break;
            case "Music":
                categoryColorId = R.color.music;
                break;
            default:
                categoryColorId = R.color.defaultColor;
                break;
        }

        return ContextCompat.getColor(getContext(), categoryColorId);
    }

    /**
     * Return the formatted date string from a Date object.
     */
    private static String formatDate(String time) {
        // Create current format
        SimpleDateFormat currentDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");

        try {
            Date parsedJsonDate = currentDate.parse(time);
            SimpleDateFormat finalDateFormatter = new SimpleDateFormat("yyyy.MM.dd / HH:mm");

            return finalDateFormatter.format(parsedJsonDate);
        } catch (ParseException e) {
            Log.e("QueryUtils", "Error parsing JSON date: ", e);
            return "";
        }
    }
}
