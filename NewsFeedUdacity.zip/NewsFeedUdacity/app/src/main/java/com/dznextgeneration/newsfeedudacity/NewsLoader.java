package com.dznextgeneration.newsfeedudacity;

import android.content.Context;
import android.nfc.Tag;
import android.support.v4.content.AsyncTaskLoader;
import android.util.Log;

import java.io.IOException;
import java.net.URL;
import java.util.List;

/**
 * Created by Lamine on 1/3/2018.
 */

/**
 * Loads a list of newsList by using an AsyncTask to perform the
 * network request to the given URL.
 */
public class NewsLoader extends android.content.AsyncTaskLoader<List<News>> {

    /** Tag for log messages */
    private static final String LOG_TAG = NewsLoader.class.getName();

    /** Query URL */
    private String mUrl;

    /**
     * Constructs a new {@link NewsLoader}.
     *
     * @param context of the activity
     * @param url to load data from
     */
    public NewsLoader(Context context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() {
        Log.i(LOG_TAG, "TEST: onStartLoading() called");
        forceLoad();
    }

    /**
     * This is on a background thread.
     */
    @Override
    public List<News> loadInBackground() {
        Log.i(LOG_TAG, "TEST: loadInBackground() called");
        if (mUrl == null) {
            return null;
        }

        // Perform the network request, parse the response, and extract a list of newsList.
        List<News> newsList = QueryUtils.fetchNewsData(mUrl);
        return newsList;
    }
}
