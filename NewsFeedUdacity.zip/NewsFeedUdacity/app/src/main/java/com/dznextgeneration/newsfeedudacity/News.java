package com.dznextgeneration.newsfeedudacity;

/**
 * Created by Lamine on 1/3/2018.
 */

public class News {

    /** Title of the news*/
    private String mTitle;

    /** Date of the news*/
    private String mDate;

    /** Url of the news*/
    private String mUrl;

    /** Url of the news*/
    private String mType;

    /** Category of the news*/
    private String mCategory;

    /**
     * Construct a new {@link News} object .
     * @param title is the title of the news .
     * @param date is the time when the news was published .
     * @param type is the type of the news.
     * @param url is the url of the new.
     *@param category is the category that the news belong to.
     */
    public News(String title, String url, String date,String type, String category) {
        mTitle = title;
        mDate = date;
        mUrl = url;
        mType = type;
        mCategory = category;
    }

    /**
     * @return the Title of the News .
     */
    public String getTitle() {
        return mTitle;
    }

    /**
     * @return the Date of the News .
     */
    public String getDate() {
        return mDate;
    }

    /**
     * @return the Url of the News .
     */
    public String getUrl() {
        return mUrl;
    }
    /**
     * @return the Type of the News .
     */
    public String getType() {
        return mType;
    }

    /**
     * @return the Category of the News .
     */
    public String getCategory() {
        return mCategory;
    }
}
